# Materials - MugBlocky

All parts share **one texture atlas** so the model imports as a single SurfaceAppearance-ready material.

- Atlas resolution: 512 x 512 px
- Texel density: 51.4 px per stud

| Slot | Kind | Colour | Roughness | Metallic | Roblox material (part version) | Source |
|---|---|---|---|---|---|---|
| Block colours (texture) | plastic | `#B2B2B2` | 0.40 | 0.00 | SmoothPlastic | one colour per block |
| Block colour 1 | plastic | `#A90A17` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |

## Texture maps

- `textures/basecolor.png` - Albedo with mild ambient occlusion baked in (Roblox has no AO slot). sRGB.
- `textures/normal.png` - Tangent-space normal map, OpenGL convention (+Y up), as Roblox requires.
- `textures/roughness.png` - Grayscale, black = glossy, white = matte.

## Roblox SurfaceAppearance mapping

| SurfaceAppearance property | File |
|---|---|
| ColorMap | textures/basecolor.png |
| NormalMap | textures/normal.png |
| RoughnessMap | textures/roughness.png |
| MetalnessMap | textures/metallic.png (if present) |
| EmissiveMaskContent | textures/emissive.png (if present) |
