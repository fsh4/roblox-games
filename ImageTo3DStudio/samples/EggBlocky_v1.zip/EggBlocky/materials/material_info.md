# Materials - EggBlocky

All parts share **one texture atlas** so the model imports as a single SurfaceAppearance-ready material.

- Atlas resolution: 1024 x 1024 px
- Texel density: 119.4 px per stud

| Slot | Kind | Colour | Roughness | Metallic | Roblox material (part version) | Source |
|---|---|---|---|---|---|---|
| Block colours (texture) | plastic | `#B2B2B2` | 0.40 | 0.00 | SmoothPlastic | one colour per block |
| Block colour 1 | plastic | `#DCBF81` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 2 | plastic | `#728681` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 3 | plastic | `#763820` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 4 | plastic | `#9DB8BA` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 5 | plastic | `#93764E` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 6 | plastic | `#E092AD` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 7 | plastic | `#FFFFDA` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 8 | plastic | `#C41E1A` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 9 | plastic | `#3C1E32` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |
| Block colour 10 | plastic | `#DBFFFF` | 0.40 | 0.00 | SmoothPlastic | clustered from the photo |

## Texture maps

- `textures/basecolor.png` - Albedo with mild ambient occlusion baked in (Roblox has no AO slot). sRGB.
- `textures/normal.png` - Tangent-space normal map, OpenGL convention (+Y up), as Roblox requires.
- `textures/roughness.png` - Grayscale, black = glossy, white = matte.

## Roblox SurfaceAppearance mapping

| SurfaceAppearance property | File |
|---|---|
| ColorMap | textures/basecolor.png |
| NormalMap | textures/normal.png |
| RoughnessMap | textures/roughness.png |
| MetalnessMap | textures/metallic.png (if present) |
| EmissiveMaskContent | textures/emissive.png (if present) |
