# Materials - Table

All parts share **one texture atlas** so the model imports as a single SurfaceAppearance-ready material.

- Atlas resolution: 512 x 512 px
- Texel density: 48.7 px per stud

| Slot | Kind | Colour | Roughness | Metallic | Roblox material (part version) | Source |
|---|---|---|---|---|---|---|
| Table top | wood | `#E1D7C8` | 0.62 | 0.00 | Wood | measured from photo |
| Legs and frame | wood | `#E2D9C9` | 0.62 | 0.00 | Wood | measured from photo |

## Texture maps

- `textures/ambient_occlusion.png` - Grayscale cavity/contact shadowing, kept separate for other engines.
- `textures/basecolor.png` - Albedo with mild ambient occlusion baked in (Roblox has no AO slot). sRGB.
- `textures/normal.png` - Tangent-space normal map, OpenGL convention (+Y up), as Roblox requires.
- `textures/roughness.png` - Grayscale, black = glossy, white = matte.

## Roblox SurfaceAppearance mapping

| SurfaceAppearance property | File |
|---|---|
| ColorMap | textures/basecolor.png |
| NormalMap | textures/normal.png |
| RoughnessMap | textures/roughness.png |
| MetalnessMap | textures/metallic.png (if present) |
| EmissiveMaskContent | textures/emissive.png (if present) |
