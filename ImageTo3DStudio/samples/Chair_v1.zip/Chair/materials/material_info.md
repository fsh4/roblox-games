# Materials - Chair

All parts share **one texture atlas** so the model imports as a single SurfaceAppearance-ready material.

- Atlas resolution: 1024 x 1024 px
- Texel density: 177.9 px per stud

| Slot | Kind | Colour | Roughness | Metallic | Roblox material (part version) | Source |
|---|---|---|---|---|---|---|
| Frame | wood | `#CEBCA7` | 0.62 | 0.00 | Wood | measured from photo |
| Seat | fabric | `#E0B0A7` | 0.92 | 0.00 | Fabric | measured from photo |

## Texture maps

- `textures/ambient_occlusion.png` - Grayscale cavity/contact shadowing, kept separate for other engines.
- `textures/basecolor.png` - Albedo with mild ambient occlusion baked in (Roblox has no AO slot). sRGB.
- `textures/normal.png` - Tangent-space normal map, OpenGL convention (+Y up), as Roblox requires.
- `textures/roughness.png` - Grayscale, black = glossy, white = matte.

## Roblox SurfaceAppearance mapping

| SurfaceAppearance property | File |
|---|---|
| ColorMap | textures/basecolor.png |
| NormalMap | textures/normal.png |
| RoughnessMap | textures/roughness.png |
| MetalnessMap | textures/metallic.png (if present) |
| EmissiveMaskContent | textures/emissive.png (if present) |
